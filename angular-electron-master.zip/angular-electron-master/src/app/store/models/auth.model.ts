export interface User {
    authToken: any;
    username: string;
    authenticated: boolean;
};
